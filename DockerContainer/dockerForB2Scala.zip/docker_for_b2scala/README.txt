To run the docker container, please type in this directory
the following commands

sudo docker build -t 'b2scala_app:1.0' .
sudo docker run b2scala_app:1.0

Note that an example program, written to model the
Needham-Schroeder protocol is in the file

needham-schroeder.scala

in the following subdirectory

exb2scala/src/main/scala/my_program

You can modify it at will to experiment with B2Scala




